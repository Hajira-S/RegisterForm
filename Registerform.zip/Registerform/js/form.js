function printError(Id,Msg){
    document.getElementById(Id).innerHTML = Msg;
}

function validateForm(){
    var name = document.Form.name.value;
    var email = document.Form.email.value;
    var mobile = document.Form.mobile.value;
    var country = document.Form.country.value;
    var gender = document.Form.gender.value;

    var nameErr = emailErr = mobileErr = countryErr = genderErr = true;
                                                      
    if(name == ""){
        printError("nameErr", "Please Enter Your Name");
        var elem = document.getElementById("name");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
    }else{
        var regex = /^[a-zA-Z\s]+$/;
        if(regex.test(name) === false){
            printError("nameErr", "Plese Enter a Valid Name");
            var elem = document.getElementById("name");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        }else{
            printError("nameErr", "");
            nameErr = false;
            var elem = document.getElementById("name");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        }
    }


    if(email == ""){
        printError("emailErr", "Please Enter Your Email Address");
        var elem = document.getElementById("email");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
    }else{
        var regex = /^\S+@\S+\.\S+$/;
        if(regex.test(email) === false){
            printError("emailErr", "Plese Enter a Valid Email Address");
            var elem = document.getElementById("email");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        }else{
            printError("emailErr", "");
            nameErr = false;
            var elem = document.getElementById("email");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        }
    }

    if(mobile == ""){
        printError("mobileErr", "Please Enter Your Mobile Number");
        var elem = document.getElementById("mobile");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
    }else{
        var regex = /^[1-9]\d{9}$/;
        if(regex.test(mobile) === false){
            printError("mobileErr", "Plese Enter a Valid 10 digit Mobile Number");
            var elem = document.getElementById("mobile");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        }else{
            printError("mobileErr", "");
            nameErr = false;
            var elem = document.getElementById("mobile");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        }
    }


    if(country == "Select"){
        printError("countryErr", "Please Select Your Country");
        var elem = document.getElementById("country");
            elem.classList.add("input-4");
            elem.classList.remove("input-3");
    }else{
        printError("countryErr", "");
        countryErr = false;
        var elem = document.getElementById("country");
            elem.classList.add("input-3");
            elem.classList.remove("input-4");
    }


    if(country == ""){
        printError("genderErr", "Please Select Your gender");
        var elem = document.getElementById("gender");
            elem.classList.add("input-4");
            elem.classList.remove("input-3");
    }else{
        printError("genderErr", "");
        genderErr = false;
        var elem = document.getElementById("gender");
            elem.classList.add("input-3");
            elem.classList.remove("input-4");
    }


    if((nameErr || emailErr || mobileErr || countryErr || genderErr == true )){
        return false;
    }
};